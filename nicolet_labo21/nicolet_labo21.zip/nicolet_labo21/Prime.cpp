/**
 * Nom du fichier  : Prime.cpp
 * Auteur(s)       : Victor Nicolet <victor.nicolet@heig-vd.ch>
 * Date creation   : 2022-12-12
 * Laboratoire n°  : 21
 * Description     : Implémentation de la fonction qui permet de faire des tests de primalité
 * Remarque(s)     :
 * Compilateur     : gcc version 11.2.0 (MinGW-W64 x86_64-posix-seh, built by Brecht Sanders)
*/

#include "Prime.hpp"

Uint exponentiationModulaire(Uint base, Uint exposant, Uint modulo) {
    Uint r(1);

    while (exposant > 0) {
        if (exposant % 2 == 0) {
            base = (base * base) % modulo;
            exposant = exposant / 2;
        } else {
            r = (r * base) % modulo;
            exposant--;
        }
    }
    return r;
}

bool prime(Uint nombrePremier) {
    if (nombrePremier < 2) {
        return false;
    }
    if (nombrePremier == 2 or nombrePremier == 3) {
        return true;
    }

    for (uint64_t i = 0; i != 10; i++) {
        Uint alea = Uint::genere_uint_aleatoire(nombrePremier);

        if (exponentiationModulaire(alea, nombrePremier - 1, nombrePremier) != (1 % nombrePremier))
            return false;

        Uint q = 1, u = nombrePremier - 1;

        while ((u % 2 == 0) && (q == 1)) {
            u = u / 2;
            q = exponentiationModulaire(alea, u, nombrePremier);

            if ((q != 1) && (q != nombrePremier - 1)) {
                return false;
            }
        }
    }
    return true;
}