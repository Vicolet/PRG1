/**
 * Nom du fichier  : Prime.hpp
 * Auteur(s)       : Victor Nicolet <victor.nicolet@heig-vd.ch>
 * Date creation   : 2022-12-12
 * Laboratoire n°  : 21
 * Description     : Déclaration de la fonction qui permet de faire des tests de primalité
 * Remarque(s)     :
 * Compilateur     : gcc version 11.2.0 (MinGW-W64 x86_64-posix-seh, built by Brecht Sanders)
*/

#include "Uint.hpp"

/**
 * @brief Fonction d'exponentiation modulaire.
 *
 * Calcule et renvoie le résultat de l'élévation de la variable base à la puissance de la variable exposante,
 * puis modulo de la variable modulo. base ^ exposant % modulo.
 *
 * @param base : La base de l'exponentiation.
 * @param exposant : L'exposant de l'exponentiation.
 * @param modulo : Le modulo à utiliser pour l'opération.
 * @return : Le résultat de l'exponentiation modulaire.
 */
Uint exponentiationModulaire(Uint base, Uint exposant, Uint modulo);

/**
 * @brief test de primalité.
 *
 * Cette fonction nous permet de savoir si le Uint demander est premier ou non grace au retour d'un booléen.
 *
 * @param nombrePremier ce paramètre représente la valeur sur la quelle on veut faire le test de primalité.
 * @return un booléen pour savoir si le nombre tester est premier True si premier False si pas premier.
 */
bool prime(Uint nombrePremier);
