/**
 * Nom du fichier  : Uint.hpp
 * Auteur(s)       : Victor Nicolet <victor.nicolet@heig-vd.ch>
 * Date creation   : 2022-12-12
 * Laboratoire n°  : 21
 * Description     : Déclaration de la class Uint qui permet de manipuler des nombres entiers naturels
 *                   de taille quelconque.
 * Remarque(s)     :
 * Compilateur     : gcc version 11.2.0 (MinGW-W64 x86_64-posix-seh, built by Brecht Sanders)
*/

#ifndef NICOLET_LABO21_UINT_HPP
#define NICOLET_LABO21_UINT_HPP

#include <iostream>

class Base {
};

class Uint {
public:
    Uint();
    Uint(std::uint64_t val);
    explicit operator uint64_t() const;

    friend std::ostream &operator<<(std::ostream &os, const Uint &rhs);
    friend std::ostream &operator<<(std::ostream &os, const Base &rhs);

    /**
     * @brief Addition de deux Uint.
     *
     * Cette surcharge d'opérateur permet de faire l'addition de deux Uint.
     *
     * @complexity : O(n)
     * @param add : Le Uint que nous voulons additioner.
     * @return : Le résultat de l'Addition de deux Uint.
     */
    Uint &operator+=(const Uint &add);

    /**
     * @brief Soustraction de deux Uint.
     *
     * Cette surcharge d'opérateur permet de faire la soustraction de deux Uint.
     *
     * @complexity : O(n)
     * @param sub : Le Uint que nous voulons soustraire.
     * @return : Le résultat de la soustraction de deux Uint.
     */
    Uint &operator-=(const Uint &sub);

    /**
     * @brief Multiplication de deux Uint.
     *
     * Cette surcharge d'opérateur permet de faire la multiplication de deux Uint.
     *
     * @complexity : O(n^2)
     * @param mul : Le Uint que nous voulons multiplier.
     * @return : Le résultat de la multiplication de deux Uint.
     */
    Uint &operator*=(const Uint &mul);

    /**
     * @brief Division de deux Uint.
     *
     * Cette surcharge d'opérateur permet de faire la division entière de deux Uint.
     *
     * @complexity : O(n^2)
     * @param div : Le Uint qui va servir de diviseur.
     * @return : Le resultat de la division entière de deux Uint.
     */
    Uint &operator/=(const Uint &div);

    /**
    * @brief Modulo de deux Uint.
    *
    * Cette surcharge d'opérateur permet de donner le reste de la division entière de deux Uint.
    *
    * @complexity : O(n^2)
    * @param mod : Le Uint qui va servir de modulo.
    * @return : Le reste de la division entière de deux Uint.
    */
    Uint &operator%=(const Uint &mod);

    /**
     * @brief Décalage de bit.
     *
     * Cette surcharge d'opérateur permet de décaler le Uint de lhs nombre de bit vers la gauche.
     *
     * @complexity : O(n^2)
     * @param lhs : Le nombre de bit que l'on veut décaler.
     * @return : retourne un Uint décaler de lhs nombre de bit.
     */
    Uint &operator<<=(const uint64_t &lhs);

    /**
     * Tous les opérateurs d'addition et de soustraction préfixé et postfixé.
     */
    Uint &operator++();
    Uint operator++(int);
    Uint &operator--();
    Uint operator--(int);

    friend Uint operator+(Uint terme1, const Uint &terme2);
    friend Uint operator-(Uint terme1, const Uint &terme2);
    friend Uint operator*(Uint facteur1, const Uint &facteur2);
    friend Uint operator/(Uint dividende, const Uint &diviseur);
    friend Uint operator%(Uint dividende, const Uint &diviseur);
    friend Uint operator<<(Uint decalage, const uint64_t &position);

    /**
     * @brief Opérateur de comparaison à trois voies.
     *
     * Cette surcharge d'opérateur permet de surcharger tous les opérateurs de comparaison.
     *
     * @param comparer : Le Uint avec le quelle on veut ce comparer.
     * @return : retourne -1 0 1 en fonction de la valeur des deux Uint comparé. retourne un booléen pour l'opérateur ==.
     */
    int operator<=>(const Uint &comparer);
    bool operator==(const Uint &comparer);

    /**
     * Cette fonction permet d'ajuste la taille de deux Uint
     * @param comparer Uint qui est ajuster ou ajuste
     */
    void ajustement(Uint &comparer);

    /**
     * Cette fonction permet d'enlever les zéros en trop devant notre string pour passer par exemple de "00101" à "101".
     */
    void enleveZero();

    /**
     * @brief Calcul le reste et la division
     *
     * Cette fonction nous permet de calculer la différence et le reste de deux Uint
     *
     * @complexity O(n^2)
     * @param div : Uint diviseur.
     * @param quotient : Uint du quotient de la division.
     * @param reste : Uint du reste de la division.
     */
    void diviserReste(const Uint &div, Uint &quotient, Uint &reste);

    /**
     * @brief Donner une base et une typo.
     *
     * Cette fonction nous permet de set la base et la typo pour la prochaine impression.
     *
     * @param base : La base voulue ( 0 à 15 ).
     * @param charactere : La typo voulu ( 0 à 1 ).
     * @return : Retourne un élément vide de la classe Base().
     */
    friend Base set_base(uint64_t base, uint64_t charactere);

    /**
     * @return : Retourne la valeur de la variable privée zeba.
     */
    static uint64_t get_base();

    /**
     * @return : Retourne la valeur de la variable privée table.
     */
    static uint64_t get_table();

    /**
     * @brief Choisis une base et un typographie.
     *
     * Cette fonction permet de choisir une base et une typographie et une base. suivant les bases et les typos dispo.
     * Les limites sont de 16 pour la base et de 2 pour la typo. (pour le moment)
     *
     * @param base : La valeur de la base voulu.
     * @param typo : La typo voulu.
     * @return : Retourne un string dans la typo et la base choisis pour un impression.
     */
    std::string change_base(uint64_t base, uint64_t typo) const;

    /**
     * @brief Générateur de Uint aléatoire.
     *
     * Cette fonction permet de générer un Uint aléatoire pouvant aller jusqu'à 2^64 bit.
     *
     * @param premier : Nous donnes une limite de taille.
     * @return : Retourne un Uint générer aléatoirement de taille premier.str.size() - 1.
     */
    static Uint genere_uint_aleatoire(const Uint &premier);

private:
    std::string str;
    static uint64_t zeba;
    static uint64_t table;


};

std::ostream &operator<<(std::ostream &os, const Base &rhs);

Base set_base(uint64_t base, uint64_t charactere = 0);

#endif //NICOLET_LABO21_UINT_HPP
